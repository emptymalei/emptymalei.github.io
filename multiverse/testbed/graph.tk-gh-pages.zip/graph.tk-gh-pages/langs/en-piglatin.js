app.ui.messages={
    "standalone":"Oo-Tay Un-Ray Is-Thay App-Ay In-Ay Ullscreen-Fay Ode-May, Add-Ay It-Ay Oo-Tay Our-Yay Ome-Hay Een-Scray.",
    "excanvasfail":"Explorer-Ay Anvas-Cay Ailed-Fay: Itting-Quay.",
    "badbrowser":"Owser-Bray Ot-Nay Upported-Say",
    "example":"Example-Ay",
    "version":"ersion-vay",
    "type":"Ype-Tay",
    "add":"Add-Ay A-Ay Ew-Nay Aph-Gray",
    "console":"Ow-Shay Onsole-Cay",
    "help":"Elp-Hay Age-Pay",
    "png":"Ake-Tay Eenshot-Scray Image-Ay",
    "showhide":"Ow-Shay/Id-Hay Aph-Gray",
    "config":"Configure-Cay",
    "reload":"Eset-Ray Aph-Gray"
};
app.ui.update_locale();